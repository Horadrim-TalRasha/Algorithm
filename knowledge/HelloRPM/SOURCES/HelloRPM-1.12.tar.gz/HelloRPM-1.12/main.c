#include <stdio.h>

int main(int argc, char** argv)
{
    printf("Hello RPM\n");
    return 0;
}
